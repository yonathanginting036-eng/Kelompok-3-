<?php
/**
 * attendance.php
 * API untuk manajemen data absensi
 * Mendukung: GET (today/report/check), POST (tambah absensi)
 */

require_once 'config.php';

$conn = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

// Route berdasarkan HTTP method
switch ($method) {
    case 'GET':
        getAttendance($conn);
        break;
    case 'POST':
        addAttendance($conn);
        break;
    default:
        sendError('Method not allowed', 405);
}

/**
 * GET: Ambil data absensi
 * Parameter ?type=:
 * - today: absensi hari ini
 * - report: laporan dengan filter tanggal
 * - check: cek apakah mahasiswa sudah absen hari ini
 */
function getAttendance($conn) {
    try {
        $type = isset($_GET['type']) ? $_GET['type'] : 'today';
        
        if ($type === 'today') {
            // Ambil absensi hari ini
            $today = date('Y-m-d');
            $query = "SELECT a.id, a.nim, s.nama, a.tanggal, a.waktu_masuk, a.status, a.created_at 
                      FROM attendance a 
                      JOIN students s ON a.nim = s.nim 
                      WHERE a.tanggal = ? 
                      ORDER BY a.waktu_masuk ASC";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $today);
            $stmt->execute();
            $result = $stmt->get_result();
            
        } elseif ($type === 'report') {
            // Ambil laporan absensi dengan filter tanggal
            $startDate = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : date('Y-m-d');
            $endDate = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : date('Y-m-d');
            
            $query = "SELECT a.id, a.nim, s.nama, a.tanggal, a.waktu_masuk, a.status, a.created_at 
                      FROM attendance a 
                      JOIN students s ON a.nim = s.nim 
                      WHERE a.tanggal BETWEEN ? AND ? 
                      ORDER BY a.tanggal DESC, a.waktu_masuk ASC";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            
        } elseif ($type === 'check') {
            // Cek apakah mahasiswa sudah absen hari ini
            $nim = isset($_GET['nim']) ? sanitize($_GET['nim']) : '';
            $today = date('Y-m-d');
            
            if (empty($nim)) {
                sendError('NIM is required');
            }
            
            $query = "SELECT id FROM attendance WHERE nim = ? AND tanggal = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $nim, $today);
            $stmt->execute();
            $result = $stmt->get_result();
            
            sendSuccess('Check completed', ['already_attended' => $result->num_rows > 0]);
            
        } else {
            sendError('Invalid type parameter');
        }
        
        // Ambil semua data dari result
        $attendance = [];
        while ($row = $result->fetch_assoc()) {
            $attendance[] = $row;
        }
        
        sendSuccess('Attendance retrieved successfully', $attendance);
        
    } catch (Exception $e) {
        sendError('Error retrieving attendance: ' . $e->getMessage(), 500);
    }
}

/**
 * POST: Tambah data absensi
 * Body JSON: { "nim": "xxx", "status": "Hadir" }
 */
function addAttendance($conn) {
    try {
        $data = getJSONInput();
        
        // Validasi field wajib
        if (empty($data['nim'])) {
            sendError('NIM is required');
        }
        
        $nim = sanitize($data['nim']);
        $status = isset($data['status']) ? sanitize($data['status']) : 'Hadir';
        $tanggal = date('Y-m-d');
        $waktu_masuk = date('H:i:s');
        
        // Validasi status
        $validStatuses = ['Hadir', 'Izin', 'Sakit', 'Alpha'];
        if (!in_array($status, $validStatuses)) {
            sendError('Invalid status value. Must be: Hadir, Izin, Sakit, or Alpha');
        }
        
        // Cek apakah mahasiswa ada
        $checkStmt = $conn->prepare("SELECT nama FROM students WHERE nim = ?");
        $checkStmt->bind_param("s", $nim);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows === 0) {
            sendError('Student not found', 404);
        }
        
        $studentData = $checkResult->fetch_assoc();
        
        // Cek apakah sudah absen hari ini
        $checkAttendanceStmt = $conn->prepare("SELECT id FROM attendance WHERE nim = ? AND tanggal = ?");
        $checkAttendanceStmt->bind_param("ss", $nim, $tanggal);
        $checkAttendanceStmt->execute();
        $attendanceResult = $checkAttendanceStmt->get_result();
        
        if ($attendanceResult->num_rows > 0) {
            sendError('Student has already attended today');
        }
        
        // Insert data absensi
        $stmt = $conn->prepare("INSERT INTO attendance (nim, tanggal, waktu_masuk, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nim, $tanggal, $waktu_masuk, $status);
        
        if ($stmt->execute()) {
            sendSuccess('Attendance recorded successfully', [
                'id' => $conn->insert_id,
                'nim' => $nim,
                'nama' => $studentData['nama'],
                'tanggal' => $tanggal,
                'waktu_masuk' => $waktu_masuk,
                'status' => $status
            ]);
        } else {
            sendError('Failed to record attendance', 500);
        }
        
    } catch (Exception $e) {
        sendError('Error adding attendance: ' . $e->getMessage(), 500);
    }
}

$conn->close();
?>