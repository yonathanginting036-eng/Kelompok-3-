<?php
/**
 * students.php
 * API untuk manajemen data mahasiswa
 * Mendukung: GET (semua/spesifik), POST (tambah), DELETE (hapus)
 */

require_once 'config.php';

$conn = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

// Route berdasarkan HTTP method
switch ($method) {
    case 'GET':
        getStudents($conn);
        break;
    case 'POST':
        addStudent($conn);
        break;
    case 'DELETE':
        deleteStudent($conn);
        break;
    default:
        sendError('Method not allowed', 405);
}

/**
 * GET: Ambil data mahasiswa
 * - Tanpa parameter: ambil semua mahasiswa
 * - Dengan ?nim=xxx: ambil mahasiswa spesifik
 */
function getStudents($conn) {
    try {
        // Cek apakah request untuk mahasiswa spesifik
        if (isset($_GET['nim'])) {
            $nim = sanitize($_GET['nim']);
            $stmt = $conn->prepare("SELECT nim, nama, email, program_studi, created_at FROM students WHERE nim = ?");
            $stmt->bind_param("s", $nim);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $student = $result->fetch_assoc();
                sendSuccess('Student found', $student);
            } else {
                sendError('Student not found', 404);
            }
        } else {
            // Ambil semua mahasiswa
            $query = "SELECT nim, nama, email, program_studi, created_at 
                      FROM students 
                      ORDER BY created_at DESC";
            $result = $conn->query($query);
            
            $students = [];
            while ($row = $result->fetch_assoc()) {
                $students[] = $row;
            }
            
            sendSuccess('Students retrieved successfully', $students);
        }
    } catch (Exception $e) {
        sendError('Error retrieving students: ' . $e->getMessage(), 500);
    }
}

/**
 * POST: Tambah mahasiswa baru
 * Body JSON: { "nim": "xxx", "nama": "xxx", "email": "xxx", "program_studi": "xxx" }
 */
function addStudent($conn) {
    try {
        $data = getJSONInput();
        
        // Validasi field wajib
        if (empty($data['nim']) || empty($data['nama'])) {
            sendError('NIM and Nama are required');
        }
        
        $nim = sanitize($data['nim']);
        $nama = sanitize($data['nama']);
        $email = isset($data['email']) ? sanitize($data['email']) : '';
        $program_studi = isset($data['program_studi']) ? sanitize($data['program_studi']) : '';
        
        // Cek apakah NIM sudah ada
        $checkStmt = $conn->prepare("SELECT nim FROM students WHERE nim = ?");
        $checkStmt->bind_param("s", $nim);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows > 0) {
            sendError('NIM already exists');
        }
        
        // Insert mahasiswa baru
        $stmt = $conn->prepare("INSERT INTO students (nim, nama, email, program_studi) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nim, $nama, $email, $program_studi);
        
        if ($stmt->execute()) {
            sendSuccess('Student registered successfully', [
                'nim' => $nim,
                'nama' => $nama,
                'email' => $email,
                'program_studi' => $program_studi
            ]);
        } else {
            sendError('Failed to register student', 500);
        }
        
    } catch (Exception $e) {
        sendError('Error adding student: ' . $e->getMessage(), 500);
    }
}

/**
 * DELETE: Hapus mahasiswa berdasarkan NIM
 * Body JSON: { "nim": "xxx" }
 */
function deleteStudent($conn) {
    try {
        $data = getJSONInput();
        
        if (empty($data['nim'])) {
            sendError('NIM is required');
        }
        
        $nim = sanitize($data['nim']);
        
        // Cek apakah mahasiswa ada
        $checkStmt = $conn->prepare("SELECT nama FROM students WHERE nim = ?");
        $checkStmt->bind_param("s", $nim);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows === 0) {
            sendError('Student not found', 404);
        }
        
        $studentData = $checkResult->fetch_assoc();
        
        // Hapus data absensi terlebih dahulu (foreign key constraint)
        $deleteAttendanceStmt = $conn->prepare("DELETE FROM attendance WHERE nim = ?");
        $deleteAttendanceStmt->bind_param("s", $nim);
        $deleteAttendanceStmt->execute();
        
        // Hapus mahasiswa
        $deleteStudentStmt = $conn->prepare("DELETE FROM students WHERE nim = ?");
        $deleteStudentStmt->bind_param("s", $nim);
        
        if ($deleteStudentStmt->execute()) {
            sendSuccess('Student deleted successfully', [
                'nim' => $nim,
                'nama' => $studentData['nama']
            ]);
        } else {
            sendError('Failed to delete student', 500);
        }
        
    } catch (Exception $e) {
        sendError('Error deleting student: ' . $e->getMessage(), 500);
    }
}

$conn->close();
?>