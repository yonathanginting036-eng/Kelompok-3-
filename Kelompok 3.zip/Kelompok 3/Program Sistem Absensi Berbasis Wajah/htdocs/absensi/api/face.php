<?php
/**
 * face.php
 * Bridge antara frontend dengan Python Face Recognition Server
 */

require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

// URL Python Face Recognition Server
define('FACE_SERVER_URL', 'http://localhost:5001');

/**
 * Helper function untuk call Python server
 */
function callFaceServer($endpoint, $data = null) {
    $url = FACE_SERVER_URL . $endpoint;
    
    $options = [
        'http' => [
            'method' => $data ? 'POST' : 'GET',
            'header' => 'Content-Type: application/json',
            'timeout' => 60,  // Increased timeout untuk training
            'ignore_errors' => true
        ]
    ];
    
    if ($data !== null) {
        $options['http']['content'] = json_encode($data);
    }
    
    $context = stream_context_create($options);
    
    try {
        $response = @file_get_contents($url, false, $context);
        
        if ($response === false) {
            // Check if Python server is running
            $healthCheck = @file_get_contents(FACE_SERVER_URL . '/health');
            if ($healthCheck === false) {
                return [
                    'success' => false,
                    'message' => 'Python Face Server tidak aktif! Pastikan sudah menjalankan: python face_server_opencv.py dari folder C:\\xampp\\htdocs\\absensi\\'
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Error connecting to Face Recognition Server'
            ];
        }
        
        return json_decode($response, true);
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error: ' . $e->getMessage()
        ];
    }
}

// Route actions
switch ($action) {
    case 'health':
        healthCheck();
        break;
    case 'capture':
        captureFace();
        break;
    case 'train':
        trainModel();
        break;
    case 'recognize':
        recognizeFace();
        break;
    case 'auto-attendance':
        autoAttendance();
        break;
    default:
        sendError('Invalid action parameter. Use: health, capture, train, recognize, auto-attendance');
}

function healthCheck() {
    $result = callFaceServer('/health');
    
    if (isset($result['status']) && $result['status'] === 'running') {
        sendSuccess('Face Recognition Server is running', $result);
    } else {
        sendError($result['message'] ?? 'Face Recognition Server is not running', 503);
    }
}

function captureFace() {
    try {
        $data = getJSONInput();
        
        if (empty($data['nim']) || empty($data['nama']) || empty($data['image'])) {
            sendError('NIM, Nama, and Image are required');
        }
        
        $result = callFaceServer('/capture-face', $data);
        
        if ($result['success'] ?? false) {
            sendSuccess($result['message'], $result['data'] ?? null);
        } else {
            sendError($result['message'] ?? 'Failed to capture face');
        }
        
    } catch (Exception $e) {
        sendError('Error: ' . $e->getMessage(), 500);
    }
}

function trainModel() {
    try {
        $result = callFaceServer('/train-model', []);
        
        if ($result['success'] ?? false) {
            sendSuccess($result['message'], $result['data'] ?? null);
        } else {
            sendError($result['message'] ?? 'Failed to train model');
        }
        
    } catch (Exception $e) {
        sendError('Error: ' . $e->getMessage(), 500);
    }
}

function recognizeFace() {
    try {
        $data = getJSONInput();
        
        if (empty($data['image'])) {
            sendError('Image is required');
        }
        
        $result = callFaceServer('/recognize-face', $data);
        
        if ($result['success'] ?? false) {
            sendSuccess($result['message'], $result['data'] ?? null);
        } else {
            sendError($result['message'] ?? 'Face not recognized');
        }
        
    } catch (Exception $e) {
        sendError('Error: ' . $e->getMessage(), 500);
    }
}

function autoAttendance() {
    try {
        $data = getJSONInput();
        
        if (empty($data['image'])) {
            sendError('Image is required');
        }
        
        $result = callFaceServer('/auto-attendance', $data);
        
        if ($result['success'] ?? false) {
            sendSuccess($result['message'], $result['data'] ?? null);
        } else {
            echo json_encode($result);
            exit();
        }
        
    } catch (Exception $e) {
        sendError('Error: ' . $e->getMessage(), 500);
    }
}
?>