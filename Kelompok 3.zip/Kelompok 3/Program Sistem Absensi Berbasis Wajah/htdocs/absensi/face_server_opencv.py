"""
face_server_opencv.py
Flask server untuk Face Recognition TANPA library face-recognition
Menggunakan OpenCV LBPH Face Recognizer (seperti versi Python desktop)
Letakkan file ini di: C:\absensi_face_server\face_server_opencv.py
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
import os
import pickle
import base64
import mysql.connector
from datetime import datetime, date
import json

app = Flask(__name__)
CORS(app)

# Konfigurasi
UPLOAD_FOLDER = 'faces'
MODEL_FILE = 'opencv_model.yml'
LABEL_MAP_FILE = 'label_map.pkl'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Database Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'attendance_db'
}

# Initialize Face Detector & Recognizer
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
recognizer = cv2.face.LBPHFaceRecognizer_create()

def get_db_connection():
    """Koneksi ke MySQL database"""
    return mysql.connector.connect(**DB_CONFIG)

@app.route('/health', methods=['GET'])
def health_check():
    """Check if server is running"""
    return jsonify({
        'status': 'running',
        'message': 'Face recognition server is active (OpenCV LBPH)',
        'method': 'OpenCV LBPH FaceRecognizer'
    })

@app.route('/capture-face', methods=['POST'])
def capture_face():
    """
    Endpoint untuk capture dan simpan wajah mahasiswa
    Body: {
        "nim": "2024001",
        "nama": "Ahmad Fauzi",
        "image": "base64_encoded_image"
    }
    """
    try:
        data = request.json
        nim = data.get('nim')
        nama = data.get('nama')
        image_data = data.get('image')
        
        if not nim or not nama or not image_data:
            return jsonify({
                'success': False,
                'message': 'NIM, Nama, dan Image required'
            }), 400
        
        # Decode base64 image
        image_data = image_data.split(',')[1] if ',' in image_data else image_data
        image_bytes = base64.b64decode(image_data)
        nparr = np.frombuffer(image_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Detect face
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))
        
        if len(faces) == 0:
            return jsonify({
                'success': False,
                'message': 'Tidak ada wajah terdeteksi. Pastikan wajah terlihat jelas.'
            }), 400
        
        if len(faces) > 1:
            return jsonify({
                'success': False,
                'message': 'Terdeteksi lebih dari 1 wajah. Pastikan hanya 1 orang di frame.'
            }), 400
        
        # Get the largest face
        faces_sorted = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
        x, y, w, h = faces_sorted[0]
        face_img = gray[y:y+h, x:x+w]
        face_resized = cv2.resize(face_img, (200, 200))
        
        # Simpan foto wajah
        student_folder = os.path.join(UPLOAD_FOLDER, nim)
        os.makedirs(student_folder, exist_ok=True)
        
        # Hitung jumlah foto yang sudah ada
        existing_photos = len([f for f in os.listdir(student_folder) if f.endswith(('.jpg', '.png'))])
        photo_filename = f"{nim}_{existing_photos + 1}.jpg"
        photo_path = os.path.join(student_folder, photo_filename)
        
        cv2.imwrite(photo_path, face_resized)
        
        return jsonify({
            'success': True,
            'message': f'Wajah berhasil disimpan! Total foto: {existing_photos + 1}',
            'data': {
                'nim': nim,
                'nama': nama,
                'photo_path': photo_path,
                'photo_count': existing_photos + 1
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

@app.route('/train-model', methods=['POST'])
def train_model():
    """
    Train model dengan semua wajah yang sudah di-capture
    """
    try:
        if not os.path.exists(UPLOAD_FOLDER):
            return jsonify({
                'success': False,
                'message': 'Belum ada data wajah untuk di-training'
            }), 400
        
        face_samples = []
        labels = []
        label_map = {}
        current_label = 0
        
        # Load semua foto dari folder
        for nim_folder in os.listdir(UPLOAD_FOLDER):
            folder_path = os.path.join(UPLOAD_FOLDER, nim_folder)
            if not os.path.isdir(folder_path):
                continue
            
            label_map[current_label] = nim_folder
            
            for img_name in os.listdir(folder_path):
                if not img_name.endswith(('.jpg', '.png')):
                    continue
                    
                img_path = os.path.join(folder_path, img_name)
                try:
                    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                    if img is None:
                        continue
                    
                    img_resized = cv2.resize(img, (200, 200))
                    face_samples.append(img_resized)
                    labels.append(current_label)
                except Exception as e:
                    print(f"Error reading image {img_path}: {e}")
                    continue
            
            current_label += 1
        
        if len(face_samples) == 0:
            return jsonify({
                'success': False,
                'message': 'Tidak ada sampel wajah yang valid untuk di-training'
            }), 400
        
        # Train recognizer
        recognizer.train(face_samples, np.array(labels))
        recognizer.write(MODEL_FILE)
        
        # Save label map
        with open(LABEL_MAP_FILE, 'wb') as f:
            pickle.dump(label_map, f)
        
        # Get student names from database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        students_info = []
        for label, nim in label_map.items():
            cursor.execute("SELECT nama FROM students WHERE nim = %s", (nim,))
            result = cursor.fetchone()
            nama = result[0] if result else "Unknown"
            students_info.append({'nim': nim, 'nama': nama})
        
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Training berhasil! Total mahasiswa: {len(label_map)}',
            'data': {
                'total_students': len(label_map),
                'total_samples': len(face_samples),
                'students': students_info
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error training: {str(e)}'
        }), 500

@app.route('/recognize-face', methods=['POST'])
def recognize_face():
    """
    Recognize wajah dari image
    Body: {
        "image": "base64_encoded_image"
    }
    """
    try:
        data = request.json
        image_data = data.get('image')
        
        if not image_data:
            return jsonify({
                'success': False,
                'message': 'Image data required'
            }), 400
        
        # Load trained model
        if not os.path.exists(MODEL_FILE) or not os.path.exists(LABEL_MAP_FILE):
            return jsonify({
                'success': False,
                'message': 'Model belum di-training. Jalankan training terlebih dahulu.'
            }), 400
        
        recognizer.read(MODEL_FILE)
        with open(LABEL_MAP_FILE, 'rb') as f:
            label_map = pickle.load(f)
        
        # Decode image
        image_data = image_data.split(',')[1] if ',' in image_data else image_data
        image_bytes = base64.b64decode(image_data)
        nparr = np.frombuffer(image_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))
        
        if len(faces) == 0:
            return jsonify({
                'success': False,
                'message': 'Tidak ada wajah terdeteksi'
            })
        
        recognized_faces = []
        
        for (x, y, w, h) in faces:
            face_img = gray[y:y+h, x:x+w]
            face_resized = cv2.resize(face_img, (200, 200))
            
            # Predict
            label, confidence = recognizer.predict(face_resized)
            
            # Confidence: lower is better (0 = perfect match)
            # Convert to percentage (100 = perfect, 0 = no match)
            confidence_percent = max(0, 100 - confidence) / 100
            
            if confidence < 70:  # Threshold: confidence < 70 means recognized
                nim = label_map.get(label, None)
                
                if nim:
                    # Get student name from database
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("SELECT nama FROM students WHERE nim = %s", (nim,))
                    result = cursor.fetchone()
                    nama = result[0] if result else "Unknown"
                    conn.close()
                    
                    recognized_faces.append({
                        'nim': nim,
                        'nama': nama,
                        'confidence': float(confidence_percent),
                        'location': {
                            'top': int(y),
                            'right': int(x + w),
                            'bottom': int(y + h),
                            'left': int(x)
                        }
                    })
        
        if len(recognized_faces) > 0:
            return jsonify({
                'success': True,
                'message': f'Terdeteksi {len(recognized_faces)} wajah dikenali',
                'data': {
                    'faces': recognized_faces
                }
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Wajah terdeteksi tapi tidak dikenali'
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error recognition: {str(e)}'
        }), 500

@app.route('/auto-attendance', methods=['POST'])
def auto_attendance():
    """
    Auto attendance dari recognized face
    Body: {
        "image": "base64_encoded_image"
    }
    """
    try:
        # Recognize face first
        data = request.json
        image_data = data.get('image')
        
        if not image_data:
            return jsonify({
                'success': False,
                'message': 'Image data required'
            }), 400
        
        # Load model
        if not os.path.exists(MODEL_FILE) or not os.path.exists(LABEL_MAP_FILE):
            return jsonify({
                'success': False,
                'message': 'Model belum di-training'
            }), 400
        
        recognizer.read(MODEL_FILE)
        with open(LABEL_MAP_FILE, 'rb') as f:
            label_map = pickle.load(f)
        
        # Decode and process image
        image_data = image_data.split(',')[1] if ',' in image_data else image_data
        image_bytes = base64.b64decode(image_data)
        nparr = np.frombuffer(image_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))
        
        if len(faces) == 0:
            return jsonify({
                'success': False,
                'message': 'Tidak ada wajah terdeteksi'
            })
        
        # Get first face
        x, y, w, h = faces[0]
        face_img = gray[y:y+h, x:x+w]
        face_resized = cv2.resize(face_img, (200, 200))
        
        label, confidence = recognizer.predict(face_resized)
        
        if confidence >= 70:
            return jsonify({
                'success': False,
                'message': 'Wajah tidak dikenali'
            })
        
        nim = label_map.get(label, None)
        if not nim:
            return jsonify({
                'success': False,
                'message': 'Wajah tidak dikenali'
            })
        
        # Get student info
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT nama FROM students WHERE nim = %s", (nim,))
        result = cursor.fetchone()
        
        if not result:
            conn.close()
            return jsonify({
                'success': False,
                'message': 'Mahasiswa tidak ditemukan di database'
            })
        
        nama = result[0]
        
        # Check if already attended today
        today = date.today().strftime('%Y-%m-%d')
        cursor.execute(
            "SELECT id FROM attendance WHERE nim = %s AND tanggal = %s",
            (nim, today)
        )
        
        if cursor.fetchone():
            conn.close()
            return jsonify({
                'success': False,
                'message': f'{nama} ({nim}) sudah absen hari ini',
                'data': {
                    'nim': nim,
                    'nama': nama,
                    'already_attended': True
                }
            })
        
        # Insert attendance
        now = datetime.now()
        waktu_masuk = now.strftime('%H:%M:%S')
        
        cursor.execute(
            "INSERT INTO attendance (nim, tanggal, waktu_masuk, status) VALUES (%s, %s, %s, %s)",
            (nim, today, waktu_masuk, 'Hadir')
        )
        conn.commit()
        conn.close()
        
        confidence_percent = max(0, 100 - confidence) / 100
        
        return jsonify({
            'success': True,
            'message': f'Absensi berhasil untuk {nama}',
            'data': {
                'nim': nim,
                'nama': nama,
                'tanggal': today,
                'waktu_masuk': waktu_masuk,
                'status': 'Hadir',
                'confidence': float(confidence_percent)
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error auto attendance: {str(e)}'
        }), 500

@app.route('/delete-face', methods=['POST'])
def delete_face():
    """
    Hapus data wajah mahasiswa
    Body: { "nim": "2024001" }
    """
    try:
        data = request.json
        nim = data.get('nim')
        
        if not nim:
            return jsonify({
                'success': False,
                'message': 'NIM required'
            }), 400
        
        # Hapus folder wajah
        student_folder = os.path.join(UPLOAD_FOLDER, nim)
        if os.path.exists(student_folder):
            import shutil
            shutil.rmtree(student_folder)
        
        return jsonify({
            'success': True,
            'message': f'Data wajah untuk NIM {nim} berhasil dihapus'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 FACE RECOGNITION SERVER (OpenCV LBPH)")
    print("=" * 60)
    print("Server berjalan di: http://localhost:5000")
    print("Method: OpenCV LBPH FaceRecognizer")
    print("Endpoints:")
    print("  - POST /capture-face    : Capture & simpan wajah")
    print("  - POST /train-model     : Training model")
    print("  - POST /recognize-face  : Recognize wajah")
    print("  - POST /auto-attendance : Auto absensi dari wajah")
    print("  - POST /delete-face     : Hapus data wajah")
    print("  - GET  /health          : Health check")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5001, debug=True)